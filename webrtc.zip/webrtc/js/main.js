import { getMedia as getMediaStream } from './media.js'
// import { call as connect } from './RTCConnect/peerConnect.js'
import { connectSignaling } from './signaling.js'



let stream = getMediaStream();
export let localStream;
let pc1;

stream
    .then(function (value) {
        connectSignaling(value);
        // connect(value)
// localStream=value;
        // .then(function(value){
        //     connectSignaling(value);
        // });
    }); 

