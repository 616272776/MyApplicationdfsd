import { pc1 } from "./peerConnect.js";
import { sendMessage } from "../signaling.js";
const offerOptions = {
  offerToReceiveAudio: 1,
  offerToReceiveVideo: 1
};
export async function createOfferSDP() {
  try {
    console.log('pc1 createOffer start');
    const offer = await pc1.createOffer(offerOptions);
    await onCreateOfferSuccess(offer);
    return offer;
  } catch (e) {
    onCreateSessionDescriptionError(e);
  }
}
async function onCreateOfferSuccess(desc) {

  console.log(`Offer from pc1\n${desc.sdp}`);
  console.log('pc1 setLocalDescription start');
  try {
    await pc1.setLocalDescription(desc);
    sendMessage(desc);
    onSetLocalSuccess(pc1);
  } catch (e) {
    onSetSessionDescriptionError(e);
  }

}
function onCreateSessionDescriptionError(error) {
  console.log(`Failed to create session description: ${error.toString()}`);
}
function onSetLocalSuccess(pc) {
  console.log(`${pc} setLocalDescription complete`);
}
function onSetSessionDescriptionError(error) {
  console.log(`Failed to set session description: ${error.toString()}`);
}
